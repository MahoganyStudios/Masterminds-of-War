﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class New : MonoBehaviour {
	
	public GameObject autosaveCanvas;
	public GameObject autosaveObj;
	
	public void Start () {
		g.gold = 250;
		g.day = 1;
		g.month = 1;
		g.year = 1;
		g.troops = 0;
		g.maxTroops = 5;
		g.slaves = 0;
		g.maxSlaves = 10;
		g.level = 1;
		g.nExp = 400;
		g.exp = 0;
	}
	public void yes(){
		autosaveCanvas.SetActive(true);
		autosaveObj.SetActive(true);
	}
	public void no(){
		autosaveCanvas.SetActive(false);
		autosaveObj.SetActive(false);
	}
	
}
