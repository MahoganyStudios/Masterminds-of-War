﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class gameStart : MonoBehaviour {
	
	public GameObject mainMenuCanvas;
	public GameObject mainCanvas;
	public GameObject mainButtonsCanvas;
	
	
	public void doLoad	() {
		mainCanvas.SetActive(true);
		mainButtonsCanvas.SetActive(true);
		mainMenuCanvas.SetActive(false);
	}
}
