﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class Save : MonoBehaviour {
	
	public GameObject saveCanvas;
	public GameObject mainCanvas;
	
	public void doSaveGame(){
		mainCanvas.SetActive(false);
		saveCanvas.SetActive(true);
	}
	
	public void doSaveGame1 () {
		TextWriter tw = new StreamWriter("Army1.MoWS");
		
		tw.WriteLine("Troops");
		tw.WriteLine(g.troops);
		tw.WriteLine("maxTroops");
		tw.WriteLine(g.maxTroops);
		tw.WriteLine("slaves");
		tw.WriteLine(g.slaves);
		tw.WriteLine("maxSlaves");
		tw.WriteLine(g.maxSlaves);
		tw.WriteLine("gold");
		tw.WriteLine(g.gold);
		tw.WriteLine("land (NOT USED)");
		tw.WriteLine(g.land);
		tw.WriteLine("day");
		tw.WriteLine(g.day);
		tw.WriteLine("month");
		tw.WriteLine(g.month);
		tw.WriteLine("year");
		tw.WriteLine(g.year);
		tw.WriteLine("level");
		tw.WriteLine(g.level);
		tw.WriteLine("experience");
		tw.WriteLine(g.exp);
		
		tw.Close();
		Debug.Log("Game Saved");
		saveCanvas.SetActive(false);
		mainCanvas.SetActive(true);
	}	
	
	public void doSaveGame2 () {
		TextWriter tw = new StreamWriter("Army2.MoWS");
		
		tw.WriteLine("Troops");
		tw.WriteLine(g.troops);
		tw.WriteLine("maxTroops");
		tw.WriteLine(g.maxTroops);
		tw.WriteLine("slaves");
		tw.WriteLine(g.slaves);
		tw.WriteLine("maxSlaves");
		tw.WriteLine(g.maxSlaves);
		tw.WriteLine("gold");
		tw.WriteLine(g.gold);
		tw.WriteLine("land (NOT USED)");
		tw.WriteLine(g.land);
		tw.WriteLine("day");
		tw.WriteLine(g.day);
		tw.WriteLine("month");
		tw.WriteLine(g.month);
		tw.WriteLine("year");
		tw.WriteLine(g.year);
		tw.WriteLine("level");
		tw.WriteLine(g.level);
		tw.WriteLine("experience");
		tw.WriteLine(g.exp);
		
		tw.Close();
		Debug.Log("Game Saved");
		saveCanvas.SetActive(false);
		mainCanvas.SetActive(true);
	}	
	
	public void doSaveGame3 () {
		TextWriter tw = new StreamWriter("Army3.MoWS");
		
		tw.WriteLine("Troops");
		tw.WriteLine(g.troops);
		tw.WriteLine("maxTroops");
		tw.WriteLine(g.maxTroops);
		tw.WriteLine("slaves");
		tw.WriteLine(g.slaves);
		tw.WriteLine("maxSlaves");
		tw.WriteLine(g.maxSlaves);
		tw.WriteLine("gold");
		tw.WriteLine(g.gold);
		tw.WriteLine("land (NOT USED)");
		tw.WriteLine(g.land);
		tw.WriteLine("day");
		tw.WriteLine(g.day);
		tw.WriteLine("month");
		tw.WriteLine(g.month);
		tw.WriteLine("year");
		tw.WriteLine(g.year);
		tw.WriteLine("level");
		tw.WriteLine(g.level);
		tw.WriteLine("experience");
		tw.WriteLine(g.exp);
		
		tw.Close();
		Debug.Log("Game Saved");
		saveCanvas.SetActive(false);
		mainCanvas.SetActive(true);
	}	
	
	public void doSaveGame4 () {
		TextWriter tw = new StreamWriter("Army4.MoWS");
		
		tw.WriteLine("Troops");
		tw.WriteLine(g.troops);
		tw.WriteLine("maxTroops");
		tw.WriteLine(g.maxTroops);
		tw.WriteLine("slaves");
		tw.WriteLine(g.slaves);
		tw.WriteLine("maxSlaves");
		tw.WriteLine(g.maxSlaves);
		tw.WriteLine("gold");
		tw.WriteLine(g.gold);
		tw.WriteLine("land (NOT USED)");
		tw.WriteLine(g.land);
		tw.WriteLine("day");
		tw.WriteLine(g.day);
		tw.WriteLine("month");
		tw.WriteLine(g.month);
		tw.WriteLine("year");
		tw.WriteLine(g.year);
		tw.WriteLine("level");
		tw.WriteLine(g.level);
		tw.WriteLine("experience");
		tw.WriteLine(g.exp);
		
		tw.Close();
		Debug.Log("Game Saved");
		saveCanvas.SetActive(false);
		mainCanvas.SetActive(true);
	}
}
