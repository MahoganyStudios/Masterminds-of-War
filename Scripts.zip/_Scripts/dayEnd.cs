﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class dayEnd : MonoBehaviour {
	
	public GameObject battleWin;
	public GameObject battleLose;
	public GameObject battleChance;
	public GameObject mainCanvas;
	public GameObject mainInfo;
	public GameObject loseTroops;
	public GameObject loseGame;
	
	public Text battleChanceText;
	public Text battleLoseText;
	public Text battleWinText;
	public Text loseTroopsText;
	
	public void continueLose(){
		loseTroops.SetActive(false);
		mainCanvas.SetActive(true);
	}
	
	public void endDay () {
		g.day = g.day + 1;
		Debug.Log("Day Change");
		if(g.day == 31){
			g.month = g.month + 1;
			g.day = 1;
			Debug.Log("Month Change");
			if(g.month == 13){
				g.year = g.year + 1;
				g.month = 1;
				Debug.Log("Year Change");
			}
		}
		g.gold = g.gold - ((g.slaves * 10) + (g.troops * 25) + (25 * (g.maxTroops/5)));
		g.gold = g.gold + ((g.slaves*(Random.value+250))/8);
		if(Random.value > 0.65){//Battle Chance
			if(g.level == 1 && g.troops == 0){
				Debug.Log("Tutorial is Still gong");
			}
			else{
				battleChance.SetActive(true);
				mainCanvas.SetActive(false);
				Debug.Log("Battle");
				double enemyForces = System.Math.Floor(((1.5*g.level) + ((((g.exp/10)/7.5)/2)/5))+(g.troops/4));
				Debug.Log("Us: " + g.troops + " vs Them: " + enemyForces);
				if(g.troops < enemyForces){//Win
					if(Random.value < (g.troops/enemyForces)/2){
						battleChanceText.text = "An Army approaches, they have " + enemyForces + " troops versus our " + g.troops + " troops\nOur strategists predict that we have a\n" + (((g.troops/enemyForces)*100)/2) + "%\nchance of winning";
						Debug.Log((((g.troops/enemyForces)*100)/2) + "% chance of win");
					}
					else{//lose
						battleChanceText.text = "An Army approaches, they have " + enemyForces + " troops versus our " + g.troops + " troops\nOur strategists predict that we have a\n" + (((g.troops/enemyForces)*100)/2) + "%\nchance of winning";
						Debug.Log((((g.troops/enemyForces)*100)/2) + "% chance of win");
					}
				}
				else{
					if(((g.troops/enemyForces)/2)*100 < 100){
						if(Random.value > (g.troops/enemyForces)/2){//Win
							battleChanceText.text = "An Army approaches, they have " + enemyForces + " troops versus our " + g.troops + " troops\nOur strategists predict that we have a\n" + (((g.troops/enemyForces)*100)/2) + "%\nchance of winning";
						}
						else{//lose
							battleChanceText.text = "An Army approaches, they have " + enemyForces + " troops versus our " + g.troops + " troops\nOur strategists predict that we have a\n" + (((g.troops/enemyForces)*100)/2) + "%\nchance of winning";
						}
					}
					else{//Auto Win
						battleChanceText.text = "An Army approaches, they have " + enemyForces + " troops versus our " + g.troops + " troops\nOur strategists predict that we have a\n100% \nchance of winning";
						Debug.Log("100% chance of winning");
					}
				}
			}
		}
		else if(g.gold <= 0 && g.troops == 0){
			mainInfo.SetActive(false);
			mainCanvas.SetActive(false);
			loseGame.SetActive(true);
		}
		else if(g.gold <= 0){
			if(System.Math.Floor(g.troops/4/2) < 2){
				loseTroopsText.text = "1 Troop has left us\ndue to the lack of gold.";
				g.troops = g.troops - 1;
			}
			else{
				loseTroopsText.text = "" + System.Math.Floor(g.troops/4) + " Troops have left us\ndue to the lack of gold.";
				g.troops = g.troops - System.Math.Floor(g.troops/4);
			}
			loseTroops.SetActive(true);
			mainCanvas.SetActive(false);
		}
		
	}

	public void battleStart () {
		battleChance.SetActive(false);
		double enemyForces = System.Math.Floor(((1.5*g.level) + ((((g.exp/10)/7.5)/2)/5))+(g.troops/4));
		g.troops = g.troops - enemyForces;
		if(g.troops > 0){//Win
			battleWin.SetActive(true);
			double nexpn = g.level*30*(Random.value)/(g.troops/10);//-------------------------------------------------------------NEVER DO THIS!!!!!!!!!!!!!
			battleWinText.text = "We Won!\nWe gained " + nexpn + " experience!";
			g.exp = g.exp + nexpn;
		}
		else{//Lose
			battleWin.SetActive(false);
			battleWinText.text = "We Lost.\nWe lost all our Troops, " + g.slaves/8 + " of our slaves and " + g.gold*.75 + " gold.";
			g.gold = g.gold*.75;
			g.slaves = g.slaves/8;
		}
	}
	
	public void battleContinue () {
		battleWin.SetActive(false);
		battleLose.SetActive(false);
		mainCanvas.SetActive(true);
	}
	
}
