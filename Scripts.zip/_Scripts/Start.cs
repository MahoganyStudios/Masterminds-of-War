﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEditor;

public class g {
	
	public static double troops, maxTroops, slaves, maxSlaves, gold, land, day, month, year, level, exp, nExp;
	
}