﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class info : MonoBehaviour {
	
	public Text troops;
	public Text slaves;
	public Text expLevel;
	public Text gold;
	public Text date;
	public GameObject notEnoughGold;
	
	void Update () {
		g.troops = System.Math.Floor(g.troops);
		g.slaves = System.Math.Floor(g.slaves);
		g.gold = System.Math.Floor(g.gold);
		g.exp = System.Math.Floor(g.exp);
		g.nExp = System.Math.Floor(g.nExp);
		notEnoughGold.SetActive(false);
		troops.text = "Troops: " + g.troops + "/" + g.maxTroops;
		slaves.text = "Slaves: " + g.slaves + "/" + g.maxSlaves;
		gold.text = "Gold: " + g.gold;
		date.text = "Date: " + g.day + "/" + g.month + "/" + g.year;
		expLevel.text = "Level: " + g.level + " | " + g.exp + "/" + g.nExp;
		if(g.troops > g.maxTroops){
			g.troops = g.maxTroops;
		}
		if(g.troops < 0){
			g.troops = 0;
		}
		if(g.exp > g.nExp){
			g.level = g.level + 1;
			g.nExp = g.nExp + (g.nExp / 2) + (400 * (g.level * 1.1));
		}
		if(g.gold < 0){
			g.gold = 0;
		}
		g.troops = System.Math.Floor(g.troops);
		g.slaves = System.Math.Floor(g.slaves);
		g.gold = System.Math.Floor(g.gold);
		g.exp = System.Math.Floor(g.exp);
		g.nExp = System.Math.Floor(g.nExp);
	}
	
	void LateUpdate () {
		g.troops = System.Math.Floor(g.troops);
		g.slaves = System.Math.Floor(g.slaves);
		g.gold = System.Math.Floor(g.gold);
		g.exp = System.Math.Floor(g.exp);
		g.nExp = System.Math.Floor(g.nExp);
		
	}
}
