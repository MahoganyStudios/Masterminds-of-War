﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class Load : MonoBehaviour {
	
	public GameObject loadCanvas;
	public GameObject mainCanvas;
	public GameObject mainMenuCanvas;
	public GameObject gameOverCanvas;
	public GameObject mainMenuInfo;
	
	public void doLoadGame (){
		mainCanvas.SetActive(false);
		mainMenuCanvas.SetActive(false);
		gameOverCanvas.SetActive(false);
		loadCanvas.SetActive(true);
		mainMenuInfo.SetActive(true);
	}
	
	public void doLoadGame1 () {
		TextReader tr = new StreamReader("Army1.MoWS");
		
		string a = tr.ReadLine();
		string troops = tr.ReadLine();
		string b = tr.ReadLine();
		string maxTroops = tr.ReadLine();
		string c = tr.ReadLine();
		string slaves = tr.ReadLine();
		string d = tr.ReadLine();
		string maxSlaves = tr.ReadLine();
		string e = tr.ReadLine();
		string gold = tr.ReadLine();
		string f = tr.ReadLine();
		string land = tr.ReadLine();
		string p = tr.ReadLine();
		string day = tr.ReadLine();
		string h = tr.ReadLine();
		string month = tr.ReadLine();
		string i = tr.ReadLine();
		string year = tr.ReadLine();
		string j = tr.ReadLine();
		string level = tr.ReadLine();
		string k = tr.ReadLine();
		string exp = tr.ReadLine();
		tr.Close();
		
		g.troops = System.Convert.ToInt32(troops);
		g.maxTroops = System.Convert.ToInt32(maxTroops);
		g.slaves = System.Convert.ToInt32(slaves);
		g.maxSlaves = System.Convert.ToInt32(maxSlaves);
		g.gold = System.Convert.ToInt32(gold);
		g.land = System.Convert.ToInt32(land);
		g.day = System.Convert.ToInt32(day);
		g.month = System.Convert.ToInt32(month);
		g.year = System.Convert.ToInt32(year);
		g.level = System.Convert.ToInt32(level);
		g.exp = System.Convert.ToInt32(exp);
		
		Debug.Log("Game Loaded");
		loadCanvas.SetActive(false);
		mainCanvas.SetActive(true);
		mainMenuInfo.SetActive(true);
	}	
	public void doLoadGame2 () {
		TextReader tr = new StreamReader("Army2.MoWS");
		
		string a = tr.ReadLine();
		string troops = tr.ReadLine();
		string b = tr.ReadLine();
		string maxTroops = tr.ReadLine();
		string c = tr.ReadLine();
		string slaves = tr.ReadLine();
		string d = tr.ReadLine();
		string maxSlaves = tr.ReadLine();
		string e = tr.ReadLine();
		string gold = tr.ReadLine();
		string f = tr.ReadLine();
		string land = tr.ReadLine();
		string p = tr.ReadLine();
		string day = tr.ReadLine();
		string h = tr.ReadLine();
		string month = tr.ReadLine();
		string i = tr.ReadLine();
		string year = tr.ReadLine();
		string j = tr.ReadLine();
		string level = tr.ReadLine();
		string k = tr.ReadLine();
		string exp = tr.ReadLine();
		tr.Close();
		
		g.troops = System.Convert.ToInt32(troops);
		g.maxTroops = System.Convert.ToInt32(maxTroops);
		g.slaves = System.Convert.ToInt32(slaves);
		g.maxSlaves = System.Convert.ToInt32(maxSlaves);
		g.gold = System.Convert.ToInt32(gold);
		g.land = System.Convert.ToInt32(land);
		g.day = System.Convert.ToInt32(day);
		g.month = System.Convert.ToInt32(month);
		g.year = System.Convert.ToInt32(year);
		g.level = System.Convert.ToInt32(level);
		g.exp = System.Convert.ToInt32(exp);
		
		Debug.Log("Game Loaded");
		loadCanvas.SetActive(false);
		mainCanvas.SetActive(true);
		mainMenuInfo.SetActive(true);
	}	
	public void doLoadGame3 () {
		TextReader tr = new StreamReader("Army3.MoWS");
		
		string a = tr.ReadLine();
		string troops = tr.ReadLine();
		string b = tr.ReadLine();
		string maxTroops = tr.ReadLine();
		string c = tr.ReadLine();
		string slaves = tr.ReadLine();
		string d = tr.ReadLine();
		string maxSlaves = tr.ReadLine();
		string e = tr.ReadLine();
		string gold = tr.ReadLine();
		string f = tr.ReadLine();
		string land = tr.ReadLine();
		string p = tr.ReadLine();
		string day = tr.ReadLine();
		string h = tr.ReadLine();
		string month = tr.ReadLine();
		string i = tr.ReadLine();
		string year = tr.ReadLine();
		string j = tr.ReadLine();
		string level = tr.ReadLine();
		string k = tr.ReadLine();
		string exp = tr.ReadLine();
		tr.Close();
		
		g.troops = System.Convert.ToInt32(troops);
		g.maxTroops = System.Convert.ToInt32(maxTroops);
		g.slaves = System.Convert.ToInt32(slaves);
		g.maxSlaves = System.Convert.ToInt32(maxSlaves);
		g.gold = System.Convert.ToInt32(gold);
		g.land = System.Convert.ToInt32(land);
		g.day = System.Convert.ToInt32(day);
		g.month = System.Convert.ToInt32(month);
		g.year = System.Convert.ToInt32(year);
		g.level = System.Convert.ToInt32(level);
		g.exp = System.Convert.ToInt32(exp);
		
		Debug.Log("Game Loaded");
		loadCanvas.SetActive(false);
		mainCanvas.SetActive(true);
		mainMenuInfo.SetActive(true);
	}	
	public void doLoadGame4 () {
		TextReader tr = new StreamReader("Army4.MoWS");
		
		string a = tr.ReadLine();
		string troops = tr.ReadLine();
		string b = tr.ReadLine();
		string maxTroops = tr.ReadLine();
		string c = tr.ReadLine();
		string slaves = tr.ReadLine();
		string d = tr.ReadLine();
		string maxSlaves = tr.ReadLine();
		string e = tr.ReadLine();
		string gold = tr.ReadLine();
		string f = tr.ReadLine();
		string land = tr.ReadLine();
		string p = tr.ReadLine();
		string day = tr.ReadLine();
		string h = tr.ReadLine();
		string month = tr.ReadLine();
		string i = tr.ReadLine();
		string year = tr.ReadLine();
		string j = tr.ReadLine();
		string level = tr.ReadLine();
		string k = tr.ReadLine();
		string exp = tr.ReadLine();
		tr.Close();
		
		g.troops = System.Convert.ToInt32(troops);
		g.maxTroops = System.Convert.ToInt32(maxTroops);
		g.slaves = System.Convert.ToInt32(slaves);
		g.maxSlaves = System.Convert.ToInt32(maxSlaves);
		g.gold = System.Convert.ToInt32(gold);
		g.land = System.Convert.ToInt32(land);
		g.day = System.Convert.ToInt32(day);
		g.month = System.Convert.ToInt32(month);
		g.year = System.Convert.ToInt32(year);
		g.level = System.Convert.ToInt32(level);
		g.exp = System.Convert.ToInt32(exp);
		
		Debug.Log("Game Loaded");
		loadCanvas.SetActive(false);
		mainCanvas.SetActive(true);
		mainMenuInfo.SetActive(true);
	}
}
