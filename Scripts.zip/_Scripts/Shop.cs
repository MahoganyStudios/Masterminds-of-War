﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Shop : MonoBehaviour {

	public GameObject shopCanvas;
	public GameObject mainCanvas;
	public GameObject troopsCanvas;
	public GameObject slavesCanvas;
	public GameObject notEnoughGold;
	public GameObject landCanvas;
	public Text troopsCostM;
	public Text slavesCostM;
	public Text landCost;

	public void openShop(){
		mainCanvas.SetActive(false);
		shopCanvas.SetActive(true);
	}
	public void closeShop(){
		shopCanvas.SetActive(false);
		mainCanvas.SetActive(true);
	}
	
	
	public void troopsOpen(){
		shopCanvas.SetActive(false);
		troopsCanvas.SetActive(true);
		
	}
	public void troopsClose(){
		notEnoughGold.SetActive(false);
		troopsCanvas.SetActive(false);
		shopCanvas.SetActive(true);
		
	}
		public void troopsOne(){
			notEnoughGold.SetActive(false);
			if (g.gold > 19 && g.troops+1 <= g.maxTroops){
				g.troops = g.troops + 1;
				g.gold = g.gold - 20;
			}
			else{
				notEnoughGold.SetActive(true);
			}
		}
		public void troopsTen(){
			notEnoughGold.SetActive(false);
			if (g.gold > 199 && g.troops+10 <= g.maxTroops){
				g.troops = g.troops + 10;
				g.gold = g.gold - 200;
			}
			else{
				notEnoughGold.SetActive(true);
			}
		}
		public void troopsFifty(){
			notEnoughGold.SetActive(false);
			if (g.gold > 999 && g.troops+50 <= g.maxTroops){
				g.troops = g.troops + 50;
				g.gold = g.gold - 1000;
			}
			else{
				notEnoughGold.SetActive(true);
			}
		}
		public void troopsMax(){
			notEnoughGold.SetActive(false);
			if (g.gold > ((20 * (g.maxTroops - g.troops)) - 1)){
				g.gold = g.gold - (20 * (g.maxTroops - g.troops));
				g.troops = g.maxTroops;
			}
			else{
				notEnoughGold.SetActive(true);
			}
		}
	
	
	
	public void slavesOpen(){
		shopCanvas.SetActive(false);
		slavesCanvas.SetActive(true);
	}
	public void slavesClose(){
		notEnoughGold.SetActive(false);
		slavesCanvas.SetActive(false);
		shopCanvas.SetActive(true);
	}
		public void slavesOne(){
			notEnoughGold.SetActive(false);
			if (g.gold > 14 && g.slaves+1 <= g.maxSlaves){
				g.slaves = g.slaves + 1;
				g.gold = g.gold - 15;
			}
			else{
				notEnoughGold.SetActive(true);
			}
		}
		public void slavesTen(){
			notEnoughGold.SetActive(false);
			if (g.gold > 149 && g.slaves+10 <= g.maxSlaves){
				g.slaves = g.slaves + 10;
				g.gold = g.gold - 150;
			}
			else{
				notEnoughGold.SetActive(true);
			}
		}
		public void slavesFifty(){
			notEnoughGold.SetActive(false);
			if (g.gold > 749 && g.slaves+50 <= g.maxSlaves){
				g.slaves = g.slaves + 50;
				g.gold = g.gold - 750;
			}
			else{
				notEnoughGold.SetActive(true);
			}
		}
		public void slavesMax(){
			notEnoughGold.SetActive(false);
			if (g.gold > ((15 * (g.maxSlaves - g.slaves)) - 1)){
				g.gold = g.gold - (15 * (g.maxSlaves - g.slaves));
				g.slaves = g.maxSlaves;
			}
			else{
				notEnoughGold.SetActive(true);
			}
		}
		
	
	
	public void landOpen(){
		shopCanvas.SetActive(false);
		landCanvas.SetActive(true);
	}
	public void landClose(){
		landCanvas.SetActive(false);
		shopCanvas.SetActive(true);
	}
		public void landBuy(){
			notEnoughGold.SetActive(false);
			if (g.gold > 2499*((g.level/10)+1)){
				g.gold = g.gold - (2499*((g.level/10)+1));
				g.maxSlaves = g.maxSlaves + 10;
				g.maxTroops = g.maxTroops + 5;
				landClose();
			}
		}
	
	
	
	void Update(){
		troopsCostM.text = "Max Troops (" + ((g.maxTroops - g.troops) * 20) + "g)";
		slavesCostM.text = "Max Slaves (" + ((g.maxSlaves - g.slaves) * 15) + "g)";
		landCost.text = "Land (" + (System.Math.Floor(2499*((g.level/10)+1))) + "g)";
	}
}
